const scroll = new SmoothScroll('.nav a[href*="#"]', {
  speed: 800,
});
